import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ResumeComponent } from './resume/resume.component';

const routes: Routes = [
  {
    path: '',
    component: HomepageComponent,
    children: [
      {path:'',redirectTo:'products', pathMatch: 'full'},
      {path: 'products',component:ProductListComponent},
      {path: 'about',component:AboutComponent},
      {path: 'details/:productId',component:ProductDetailsComponent},
    ],
  },
  {path: 'resume',component:ResumeComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
