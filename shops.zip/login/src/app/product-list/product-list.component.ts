import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  productList:any[] = [];
  constructor(
    private api: ApiService,
    private router:Router
  ) { }

  ngOnInit(): void {
    
    this.api.apiCall().subscribe((data:any) => {
      this.productList = data;
      console.log("get api data");
    });
  }

  routeToDetailPage(productId:number) {
    this.router.navigate(['details',productId]);
  }

}
