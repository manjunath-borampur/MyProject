import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  constructor(private activatedRoute:ActivatedRoute,private api:ApiService) { }
  product: any;

  ngOnInit(): void {
    const productId = this.activatedRoute.snapshot.paramMap.get('productId');
    this.api.getProductDetails(productId).subscribe((data: any) => {
      console.log(data);
      this.product = data;
    });
    console.log(productId);
  }

}
