export const environment = {
  production: true,
  url:'https://fakestoreapi.com'
};
