import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  productList:any[] = [];
  categoryList:any[]=[];
  constructor(
    private api: ApiService,
    private router:Router
  ) { }

  ngOnInit(): void {
    this.getAllProducts();
    this.getAllCategory();
  }


  getAllCategory(){
    this.api.getAllCategory().subscribe((data:any)=>{
      this.categoryList=data;
        console.log(data)
    })
  }

  slectedCategory(category:any){
    console.log(category.target.value);

    if(category.target.value!='All'){
       this.getProductsByCategory(category.target.value);
    }else{
     this.getAllProducts();
    }
  }


  getProductsByCategory(category:String){
    this.api.getProductByCategory(category).subscribe((data:any)=>{
      console.log(data);
      this.productList = data;
    })
  }


  getAllProducts(){
    this.api.apiCall().subscribe((data:any) => {
      this.productList = data;
      console.log("get api data");
    });
  }



  routeToDetailPage(productId:number) {
    this.router.navigate(['details',productId]);
  }

}
