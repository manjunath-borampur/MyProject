import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  apiUrl:String = environment.url;

  constructor(private http: HttpClient) {
    
  }
  apiCall(){
    return this.http.get(this.apiUrl+'/products');
  }
  getAllCategory(){
    return this.http.get(this.apiUrl+'/products/categories');
  }

  getProductByCategory(category:String){
    return this.http.get(this.apiUrl+'/products/category/'+category);
  }

  getProductDetails(productId:any) {
    return this.http.get(this.apiUrl+"/products/"+productId);
  }

}
